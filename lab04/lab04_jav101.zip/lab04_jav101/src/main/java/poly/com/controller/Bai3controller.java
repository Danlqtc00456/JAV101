package poly.com.controller;

import java.io.File;
import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

@MultipartConfig
@WebServlet("/add")
public class Bai3controller extends HttpServlet {

	private static final long serialVersionUID = 1L;
	// Thư mục lưu ảnh ngoài Tomcat, đảm bảo user chạy Eclipse/Tomcat có quyền ghi
	private static final String UPLOAD_DIRECTORY = "D:/uploads";

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.getRequestDispatcher("form.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String gender = request.getParameter("gender");
		String married = request.getParameter("married");
		String country = request.getParameter("country");
		String[] hobbies = request.getParameterValues("hobbies");
		String note = request.getParameter("note");

		// Lấy ảnh
		Part filePart = request.getPart("poto_file");
		String filename = filePart.getSubmittedFileName();

		// Lấy đường dẫn thật đến thư mục uploads trong webapp
		String appPath = request.getServletContext().getRealPath("");
		String uploadPath = appPath + "uploads";

		File uploadDir = new File(uploadPath);
		if (!uploadDir.exists())
			uploadDir.mkdir();

		// Lưu file
		String filePath = uploadPath + File.separator + filename;
		filePart.write(filePath);

		// URL để hiển thị ảnh (không dùng file:///)
		String photoURL = "uploads/" + filename;

		// Gửi sang JSP
		request.setAttribute("username", username);
		request.setAttribute("password", password);
		request.setAttribute("gender", gender);
		request.setAttribute("married", married != null ? "Yes" : "No");
		request.setAttribute("country", country);
		request.setAttribute("hobbies", hobbies);
		request.setAttribute("note", note);
		request.setAttribute("photoURL", photoURL);

		request.getRequestDispatcher("/ketqua.jsp").forward(request, response);

	}
}

package poly.com.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/form")
public class Bai3controller extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.getRequestDispatcher("form.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");

		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String gender = request.getParameter("gender");
		String familyParam = request.getParameter("family");
		boolean isMarried = "yes".equals(familyParam);
		String country = request.getParameter("country");
		String note = request.getParameter("note");
		String[] hobbies = request.getParameterValues("hobby");

		System.out.println("Username: " + username);
		System.out.println("Password: " + password);
		System.out.println("Gender: " + gender);
		System.out.println("Family: " + isMarried);
		System.out.println("Country: " + country);
		System.out.print("Hobbies: ");
		if (hobbies != null) {
			for (String h : hobbies)
				System.out.print(h + " ");
		}
		System.out.println();
		System.out.println("Note: " + note);

		response.getWriter().println("<h2>Dang ky thanh cong!</h2>");
		response.getWriter().println("<p>Username: " + username + "</p>");
		response.getWriter().println("<p>Password: " + password + "</p>");
		response.getWriter().println("<p>Gender: " + gender + "</p>");
		response.getWriter().println("<p>Family: " + (isMarried ? "Da co gia dinh" : "Chua co gia dinh") + "</p>");
		response.getWriter().println("<p>Country: " + country + "</p>");
		response.getWriter().print("<p>Hobbies: ");
		if (hobbies != null) {
			for (String h : hobbies)
				response.getWriter().print(h + " ");
		}
		response.getWriter().println("</p>");
		response.getWriter().println("<p>Note: " + note + "</p>");
	}
}

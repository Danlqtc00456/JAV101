package poly.com.controller;

import java.io.File;
import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

@MultipartConfig
@WebServlet("/add")
public class Bai3controller extends HttpServlet {

    private static final long serialVersionUID = 1L;
    // Thư mục lưu ảnh ngoài Tomcat, đảm bảo user chạy Eclipse/Tomcat có quyền ghi
    private static final String UPLOAD_DIRECTORY = "D:/uploads";

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("form.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String gender = request.getParameter("gender");
        String married = request.getParameter("married");
        String country = request.getParameter("country");
        String[] hobbies = request.getParameterValues("hobbies");
        String note = request.getParameter("note");

        Part filePart = request.getPart("poto_file"); // Lấy ảnh đại diện
        String filename = filePart.getSubmittedFileName(); // Tên file

        // Tạo thư mục lưu nếu chưa tồn tại
        File uploadDir = new File(UPLOAD_DIRECTORY);
        if (!uploadDir.exists()) {
            uploadDir.mkdirs();
        }

        String filePath = UPLOAD_DIRECTORY + File.separator + filename;
        filePart.write(filePath);

        // Đường dẫn hiển thị ảnh trên JSP (bạn có thể copy file vào folder web nếu muốn)
        String photoURL = "file:///" + filePath.replace("\\", "/");

        request.setAttribute("username", username);
        request.setAttribute("password", password);
        request.setAttribute("gender", gender);
        request.setAttribute("married", married != null ? "Yes" : "No");
        request.setAttribute("country", country);
        request.setAttribute("hobbies", hobbies);
        request.setAttribute("note", note);
        request.setAttribute("photoURL", photoURL);

        request.getRequestDispatcher("/ketqua.jsp").forward(request, response);
    }
}

package poly.com.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/bai3")
public class Bai3controller extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String url = req.getRequestURL().toString();   // URL đầy đủ
	    String uri = req.getRequestURI();              // URI
	    String queryString = req.getQueryString();           // Query string
	    String servletPath = req.getServletPath();     // Servlet path
	    String contextPath = req.getContextPath();     // Tên project
	    String pathInfo = req.getPathInfo();           // Phần path dư
	    String method = req.getMethod();               // GET / POST

	    resp.getWriter().println("<h2>THONG TIN URL</h2>");
	    resp.getWriter().println("1. URL: " + url + "<br>");
	    resp.getWriter().println("2. URI: " + uri + "<br>");
	    resp.getWriter().println("3. QueryString: " + queryString + "<br>");
	    resp.getWriter().println("4. ServletPath: " + servletPath + "<br>");
	    resp.getWriter().println("5. ContextPath: " + contextPath + "<br>");
	    resp.getWriter().println("6. PathInfo: " + pathInfo + "<br>");
	    resp.getWriter().println("7. Method: " + method + "<br>");
	}
}

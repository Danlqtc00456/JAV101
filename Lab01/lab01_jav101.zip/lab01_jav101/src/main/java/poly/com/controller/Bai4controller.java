package poly.com.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet({"/bai4","/crud/create","/crud/update","/crud/delete","/crud/edit/2024"})
public class Bai4controller extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String uri = req.getRequestURI();
		//Kiểm tra từng đường dẫn và xuất thong tin ứng dụng
		if (uri.contains("/crud/create"))
			resp.getWriter().println("<h1>Ban Dang Them Du Lieu...</h1>");			
		else if (uri.contains("/crud/update"))
			resp.getWriter().println("<h1>Ban Dang Sua Du Lieu...</h1>");
		else if (uri.contains("/crud/delete"))
			resp.getWriter().println("<h1>Ban Dang Xoa Du Lieu...</h1>");
		else if (uri.contains("/crud/edit/2024"))
			resp.getWriter().println("<h1>Ban Dang Edit Du Lieu...</h1>");
		else
			resp.getWriter().println("<h1> not knowm </h1>");

	}
}
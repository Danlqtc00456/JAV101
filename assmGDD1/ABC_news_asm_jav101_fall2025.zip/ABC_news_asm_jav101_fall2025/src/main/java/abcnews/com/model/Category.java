package abcnews.com.model;

public class Category {

}

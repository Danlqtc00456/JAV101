package abcnews.com.controller.reader;

public class NewsDetailServlet {

}

package abcnews.com.controller.admin;

public class AdminNewsServlet {

}

package abcnews.com.model;

public class News {

}

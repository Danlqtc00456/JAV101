package abcnews.com.dao;

public class NewsletterDAO {

}

package abcnews.com.controller.reader;

public class NewsListServlet {

}

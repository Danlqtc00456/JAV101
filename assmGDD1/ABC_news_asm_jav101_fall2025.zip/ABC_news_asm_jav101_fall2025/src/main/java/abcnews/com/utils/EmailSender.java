package abcnews.com.utils;

public class EmailSender {

}
